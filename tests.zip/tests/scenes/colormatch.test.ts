import { describe, it, expect, beforeEach } from 'vitest';
import { ColorMatchScene } from '../../src/client/scenes/ColorMatchScene';

describe('ColorMatchScene', () => {
  let scene: ColorMatchScene;

  beforeEach(() => {
    scene = new ColorMatchScene();
  });

  it('should initialize properly', () => {
    expect(scene).toBeDefined();
    expect(scene.scene.key).toBe('ColorMatchScene');
  });

  it('should create UI elements', () => {
    scene.create();
    // Verify UI elements were created
    expect(scene.add.text).toHaveBeenCalled();
  });
});
