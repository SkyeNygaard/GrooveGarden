import { describe, it, expect, beforeEach, vi } from 'vitest';

vi.mock('phaser', () => {
  return {
    default: {
      Scene: class {
        constructor() {}
      }
    },
  }
});

import { SelectionScene } from '../../src/client/scenes/SelectionScene';

describe('SelectionScene', () => {
  let scene: SelectionScene;

  beforeEach(() => {
    scene = new SelectionScene();
    scene.scene = {
      start: vi.fn(),
    } as any;
  });

  it('can be instantiated', () => {
    expect(scene).toBeInstanceOf(SelectionScene);
  });

  it('can transition to game scenes', () => {
    // Test transition to TapBeat game
    if (scene.startGame) {
      scene.startGame('TapBeatScene');
      expect(scene.scene.start).toHaveBeenCalledWith('TapBeatScene');
    }
  });
});
