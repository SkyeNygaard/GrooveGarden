import { describe, it, expect, beforeEach, vi } from 'vitest';

vi.mock('phaser', () => {
  return {
    default: {
      Scene: class {
        constructor() {}
      }
    },
  }
});

import { IntroScene } from '../../src/client/scenes/IntroScene';

describe('IntroScene', () => {
  let scene: IntroScene;

  beforeEach(() => {
    scene = new IntroScene();
    // Mock minimum required methods
    scene.scene = {
      start: vi.fn(),
    } as any;
  });

  it('can be instantiated', () => {
    expect(scene).toBeInstanceOf(IntroScene);
  });

  it('transitions to selection scene on input', () => {
    // Simulate click/tap
    if (scene.handleClick) {
      scene.handleClick();
      expect(scene.scene.start).toHaveBeenCalledWith('SelectionScene');
    }
  });
});
