import { describe, it, expect, beforeEach } from 'vitest';
import { BeatBoxScene } from '../../src/client/scenes/BeatBoxScene';

describe('BeatBoxScene', () => {
  let scene: BeatBoxScene;

  beforeEach(() => {
    scene = new BeatBoxScene();
  });

  it('should initialize properly', () => {
    expect(scene).toBeDefined();
    expect(scene.scene.key).toBe('BeatBoxScene');
  });

  it('should create managers and UI', () => {
    scene.create();
    // Verify that score text was added
    expect(scene.add.text).toHaveBeenCalledWith(16, 16, 'Score: 0', expect.any(Object));
  });

  it('should handle beat events', () => {
    scene.create();
    scene.onBeat(1, Date.now());
    // Beat should trigger camera flash
    expect(scene.cameras.main.flash).toHaveBeenCalled();
  });
});
