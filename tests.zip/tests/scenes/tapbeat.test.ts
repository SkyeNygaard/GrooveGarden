import { describe, it, expect, beforeEach } from 'vitest';
import { TapBeatScene } from '../../src/client/scenes/TapBeatScene';

describe('TapBeatScene', () => {
  let scene: TapBeatScene;

  beforeEach(() => {
    scene = new TapBeatScene();
  });

  it('should initialize properly', () => {
    expect(scene).toBeDefined();
    expect(scene.scene.key).toBe('TapBeatScene');
  });

  it('should create UI elements', () => {
    scene.create();
    // Verify UI elements were created
    expect(scene.add.text).toHaveBeenCalled();
  });
});
