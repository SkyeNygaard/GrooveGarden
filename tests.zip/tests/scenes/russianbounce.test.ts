import { describe, it, expect, beforeEach } from 'vitest';
import { RussianBounceScene } from '../../src/client/scenes/RussianBounceScene';

describe('RussianBounceScene', () => {
  let scene: RussianBounceScene;

  beforeEach(() => {
    scene = new RussianBounceScene();
  });

  it('should initialize properly', () => {
    expect(scene).toBeDefined();
    expect(scene.scene.key).toBe('RussianBounceScene');
  });

  it('should create UI elements', () => {
    scene.create();
    // Verify UI elements were created
    expect(scene.add.text).toHaveBeenCalled();
  });
});
