import { describe, it, expect, beforeEach } from 'vitest';
import { SoundSyncScene } from '../../src/client/scenes/SoundSyncScene';

describe('SoundSyncScene', () => {
  let scene: SoundSyncScene;

  beforeEach(() => {
    scene = new SoundSyncScene();
  });

  it('should initialize properly', () => {
    expect(scene).toBeDefined();
    expect(scene.scene.key).toBe('SoundSyncScene');
  });

  it('should create UI elements', () => {
    scene.create();
    // Verify UI elements were created
    expect(scene.add.text).toHaveBeenCalled();
  });
});
