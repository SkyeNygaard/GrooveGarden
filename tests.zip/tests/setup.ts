import { vi } from "vitest";

// Mock canvas context
const mockContext = {
  fillStyle: "#000000",
  strokeStyle: "#000000",
  fillRect: vi.fn(),
  beginPath: vi.fn(),
  arc: vi.fn(),
  fill: vi.fn(),
  stroke: vi.fn(),
  clearRect: vi.fn(),
  save: vi.fn(),
  restore: vi.fn(),
  scale: vi.fn(),
  translate: vi.fn(),
  rotate: vi.fn(),
  moveTo: vi.fn(),
  lineTo: vi.fn(),
  closePath: vi.fn(),
};

// Mock canvas element
const mockCanvas = {
  getContext: vi.fn(() => mockContext),
  style: {},
  width: 800,
  height: 600,
};

global.HTMLCanvasElement.prototype.getContext = vi.fn(() => mockContext);
Object.defineProperties(global.HTMLCanvasElement.prototype, {
  width: { get: () => 800, set: () => {} },
  height: { get: () => 600, set: () => {} },
  style: { get: () => ({}) },
});

// Mock Phaser namespace
const mockPhaser = {
  Scene: class {
    add = {
      text: vi.fn().mockReturnValue({
        setOrigin: vi.fn().mockReturnThis(),
        setInteractive: vi.fn().mockReturnThis(),
        on: vi.fn().mockReturnThis(),
        setStyle: vi.fn().mockReturnThis(),
        destroy: vi.fn(),
      }),
      image: vi.fn().mockReturnValue({
        setInteractive: vi.fn().mockReturnThis(),
        on: vi.fn().mockReturnThis(),
        destroy: vi.fn(),
      }),
      sprite: vi.fn().mockReturnValue({
        destroy: vi.fn(),
      }),
      circle: vi.fn().mockReturnValue({
        x: 0,
        y: 0,
        destroy: vi.fn(),
      }),
    };
    scene = {
      start: vi.fn(),
      stop: vi.fn(),
      key: 'IntroScene',
    };
    cameras = {
      main: {
        setBackgroundColor: vi.fn(),
        flash: vi.fn(),
        width: 800,
        height: 600,
      },
    };
    input = {
      on: vi.fn(),
      keyboard: {
        addKey: vi.fn().mockReturnValue({
          on: vi.fn(),
        }),
      },
    };
    load = {
      image: vi.fn(),
      audio: vi.fn(),
    };
    tweens = {
      add: vi.fn(),
      killAll: vi.fn(),
    };
    sound = {
      add: vi.fn().mockReturnValue({
        play: vi.fn(),
        stop: vi.fn(),
      }),
      stopAll: vi.fn(),
    };
    time = {
      addEvent: vi.fn(),
      delayedCall: vi.fn(),
      now: Date.now(),
      removeAllEvents: vi.fn(),
    };
  },
  Game: class {
    constructor() {
      return {
        canvas: mockCanvas,
      };
    }
  },
  AUTO: 'AUTO',
  Scale: {
    RESIZE: 'RESIZE',
  },
  Math: {
    Between: vi.fn().mockReturnValue(100),
  },
  GameObjects: {
    Text: class {},
    Image: class {},
    Sprite: class {},
  },
};

// Mock global Phaser
global.Phaser = mockPhaser;

// Mock requestAnimationFrame
global.requestAnimationFrame = vi.fn((callback) => setTimeout(callback, 0));
global.cancelAnimationFrame = vi.fn();

vi.mock('phaser', () => ({
  default: mockPhaser,
  Scene: mockPhaser.Scene,
  Game: mockPhaser.Game,
  AUTO: mockPhaser.AUTO,
  Scale: mockPhaser.Scale,
  Math: mockPhaser.Math,
  GameObjects: mockPhaser.GameObjects,
}));
