import { useEffect } from 'react';
import { Game, GameConfig } from './game/Game';
import './App.css';

function App() {
    useEffect(() => {
        const game = new Game(GameConfig);
        
        return () => {
            game.destroy(true);
        };
    }, []);

    return (
        <div id="game-container" style={{
            width: '100vw',
            height: '100vh',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: '#000'
        }}></div>
    );
}

export default App;
