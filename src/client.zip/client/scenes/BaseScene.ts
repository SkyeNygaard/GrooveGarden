import Phaser from "phaser";
import { BeatListener } from "../core/interfaces/BeatListener";
import { InputListener } from "../core/input/InputManager";
import { InputManager } from "../core/input/InputManager";
import { SongManager } from "../core/managers/SongManager";

export class BaseScene extends Phaser.Scene implements BeatListener, InputListener {
	protected songManager!: SongManager;
	protected inputManager!: InputManager;

	create() {
		// Initialize managers
		this.songManager = new SongManager(this);
		this.inputManager = new InputManager(this);

		// Add escape key handler
		this.input.keyboard?.on("keydown-ESC", () => {
			// Stop any music that might be playing
			this.sound.stopAll();
			// Return to selection scene
			this.scene.start("SelectionScene");
		});

		// Set up resize listener
		this.scale.on("resize", this.resize, this);

		// Initial resize
		this.resize(this.scale.gameSize);

		// Setup input handling
		this.inputManager.addListener("keydown", this);
		this.inputManager.addListener("pointerdown", this);
	}

	resize(gameSize: Phaser.Structs.Size) {
		const width = gameSize.width;
		const height = gameSize.height;

		this.cameras.resize(width, height);
	}

	// BeatListener implementation
	onBeat(beatNumber: number, time: number): void {
		// Base implementation - override in derived classes
		this.cameras.main.flash(100, 255, 255, 255, 0.2);
	}

	onBeatEarly(beatNumber: number, timeDiff: number): void {
		// Base implementation - override in derived classes
		this.cameras.main.flash(100, 255, 0, 0, 0.2);
	}

	onBeatLate(beatNumber: number, timeDiff: number): void {
		// Base implementation - override in derived classes
		this.cameras.main.flash(100, 0, 0, 255, 0.2);
	}

	// InputListener implementation
	onInput(type: string, event: any): void {
		if (type === "keydown" || type === "pointerdown") {
			// Check if this input matches with a beat
			this.songManager.getBeatManager().checkBeatHit(Date.now());
		}
	}

	update() {
		this.songManager.update();
	}

	shutdown() {
		this.songManager.stop();
		this.inputManager.removeListener("keydown", this);
		this.inputManager.removeListener("pointerdown", this);
	}
}
