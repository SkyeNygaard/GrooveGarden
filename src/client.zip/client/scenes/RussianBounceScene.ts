import { BaseScene } from "./BaseScene";

export class RussianBounceScene extends BaseScene {
	private score: number = 0;
	private scoreText?: Phaser.GameObjects.Text;
	private platform?: Phaser.GameObjects.Rectangle;
	private ball?: Phaser.GameObjects.Arc;
	private ballVelocity: number = 0;
	private gravity: number = 0.5;

	create() {
		super.create();

		const { width, height } = this.cameras.main;

		// Setup UI
		this.scoreText = this.add.text(16, 16, "Score: 0", {
			fontSize: "32px",
			color: "#fff",
		});

		// Create platform
		this.platform = this.add.rectangle(width / 2, height - 50, 200, 20, 0x00ff00);

		// Create ball
		this.ball = this.add.circle(width / 2, height / 2, 15, 0xff0000);

		// Load and start song
		this.songManager.loadSong({
			key: "russianbounce-song",
			bpm: 140,
			duration: 60,
		});

		// Register as beat listener
		this.songManager.getBeatManager().addListener(this);

		// Start the song
		this.songManager.play();
	}

	onBeat(beatNumber: number, time: number): void {
		super.onBeat(beatNumber, time);
		if (this.ball && this.ball.y >= this.cameras.main.height - 80) {
			this.ballVelocity = -15; // Give the ball an upward boost on the beat
			this.score += 100;
			if (this.scoreText) {
				this.scoreText.setText(`Score: ${this.score}`);
			}
		}
	}

	onInput(type: string, event: any): void {
		super.onInput(type, event);
		if (type === "keydown") {
			const key = event.key.toLowerCase();
			if (key === "arrowleft" && this.platform) {
				this.platform.x = Math.max(
					this.platform.width / 2,
					this.platform.x - 50,
				);
			} else if (key === "arrowright" && this.platform) {
				this.platform.x = Math.min(
					this.cameras.main.width - this.platform.width / 2,
					this.platform.x + 50,
				);
			}
		}
	}

	update() {
		super.update();
		if (this.ball) {
			// Apply gravity
			this.ballVelocity += this.gravity;
			this.ball.y += this.ballVelocity;

			// Check for platform collision
			if (
				this.platform &&
				this.ball.y >= this.cameras.main.height - 80 &&
				this.ball.x >= this.platform.x - this.platform.width / 2 &&
				this.ball.x <= this.platform.x + this.platform.width / 2
			) {
				this.ball.y = this.cameras.main.height - 80;
				this.ballVelocity = 0;
			}

			// Check for screen bounds
			if (this.ball.y > this.cameras.main.height + 50) {
				this.ball.y = this.cameras.main.height / 2;
				this.ball.x = this.cameras.main.width / 2;
				this.ballVelocity = 0;
				this.score = Math.max(0, this.score - 50);
				if (this.scoreText) {
					this.scoreText.setText(`Score: ${this.score}`);
				}
			}
		}
	}

	shutdown() {
		super.shutdown();
		this.platform?.destroy();
		this.ball?.destroy();
		this.score = 0;
	}
}
