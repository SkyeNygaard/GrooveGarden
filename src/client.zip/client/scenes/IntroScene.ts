import Phaser from "phaser";

export class IntroScene extends Phaser.Scene {
	private circles: Phaser.GameObjects.Arc[] = [];
	private titleText?: Phaser.GameObjects.Text;
	private clickText?: Phaser.GameObjects.Text;

	constructor() {
		super({ key: "IntroScene" });
	}

	create() {
		const width = this.cameras.main.width;
		const height = this.cameras.main.height;

		// Set background to white (Rhythm Heaven often uses simple, bold colors)
		this.cameras.main.setBackgroundColor("#FFFFFF");

		// Create bouncing circles (typical Rhythm Heaven playful elements)
		const colors = [0xff0000, 0x00ff00, 0x0000ff, 0xffff00];
		for (let i = 0; i < 4; i++) {
			const circle = this.add.circle(
				Phaser.Math.Between(100, width - 100),
				Phaser.Math.Between(100, height - 100),
				20,
				colors[i],
			);

			this.tweens.add({
				targets: circle,
				y: circle.y + 50,
				duration: 600,
				ease: "Bounce",
				yoyo: true,
				repeat: -1,
				delay: i * 200,
			});

			this.circles.push(circle);
		}

		// Add title with a simple bounce effect
		this.titleText = this.add.text(
			width / 2,
			height / 2 - 50,
			"GROOVE\nGARDEN",
			{
				fontSize: "64px",
				fontFamily: "Arial Black",
				color: "#000000",
				align: "center",
				lineSpacing: 10,
			},
		);
		this.titleText.setOrigin(0.5);

		// Simple scaling animation for the title
		this.tweens.add({
			targets: this.titleText,
			scaleX: 1.1,
			scaleY: 1.1,
			duration: 450,
			yoyo: true,
			repeat: -1,
			ease: "Quad.easeInOut",
		});

		// Add "TAP TO START!" text with a blink animation
		this.clickText = this.add.text(width / 2, height * 0.7, "TAP TO START!", {
			fontSize: "32px",
			fontFamily: "Arial Black",
			color: "#FF0000",
		});
		this.clickText.setOrigin(0.5);

		// Blink animation for start text
		this.tweens.add({
			targets: this.clickText,
			alpha: 0,
			duration: 500,
			yoyo: true,
			repeat: -1,
		});

		// Make the entire scene clickable
		this.input.on("pointerdown", () => {
			// Flash the screen white
			const flash = this.add.rectangle(0, 0, width, height, 0xffffff);
			flash.setOrigin(0, 0);
			flash.setAlpha(0);

			this.tweens.add({
				targets: flash,
				alpha: 1,
				duration: 100,
				yoyo: true,
				onComplete: () => {
					// Transition to the selection scene
					this.scene.start("SelectionScene");
				},
			});
		});
	}
}
