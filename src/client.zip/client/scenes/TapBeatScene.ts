import Phaser from "phaser";
import { BaseScene } from "./BaseScene";

export class TapBeatScene extends BaseScene {
	private score: number = 0;
	private scoreText?: Phaser.GameObjects.Text;
	private tapTargets: Phaser.GameObjects.Rectangle[] = [];

	constructor() {
		super({ key: "TapBeatScene" });
	}

	preload() {}

	async create() {
		super.create();

		// Setup UI
		this.scoreText = this.add.text(16, 16, "Score: 0", {
			fontSize: "32px",
			color: "#fff",
		});

		// Load and start song
		this.songManager = new SongManager(this);
		this.songManager.loadSong({
			key: "tapbeat-song",
			bpm: 120,
			duration: 60,
		});

		// Register as beat listener
		this.songManager.getBeatManager().addListener(this);

		// Start the song
		this.songManager.play();
	}

	onBeat(beatNumber: number, time: number): void {
		super.onBeat(beatNumber, time);
		this.createTapTarget();
	}

	onInput(type: string, event: any): void {
		super.onInput(type, event);
		if (type === "keydown" || type === "pointerdown") {
			this.checkTapTargets();
		}
	}

	private createTapTarget() {
		const { width, height } = this.cameras.main;
		const target = this.add.rectangle(
			width / 2,
			height - 100,
			60,
			60,
			0xffff00,
		);
		this.tapTargets.push(target);

		this.tweens.add({
			targets: target,
			y: 100,
			duration: 2000,
			ease: "Linear",
			onComplete: () => {
				const index = this.tapTargets.indexOf(target);
				if (index !== -1) {
					this.tapTargets.splice(index, 1);
				}
				target.destroy();
			},
		});
	}

	private checkTapTargets() {
		for (let i = this.tapTargets.length - 1; i >= 0; i--) {
			const target = this.tapTargets[i];
			if (target.y > 300 && target.y < 500) {
				this.score += 100;
				if (this.scoreText) {
					this.scoreText.setText(`Score: ${this.score}`);
				}
				target.destroy();
				this.tapTargets.splice(i, 1);
				break;
			}
		}
	}

	shutdown() {
		super.shutdown();
		this.tapTargets.forEach((target) => target.destroy());
		this.tapTargets = [];
		this.score = 0;
	}
}
