import Phaser from "phaser";
import { AudioAnalyzer } from "../utils/audioAnalysis";
import { BaseScene } from "./BaseScene";

interface ColorNote {
	circle: Phaser.GameObjects.Arc;
	color: number;
	colorName: string;
	startTime: number;
	hit: boolean;
}

export class ColorMatchScene extends BaseScene {
	private music?: Phaser.Sound.BaseSound;
	private audioAnalyzer?: AudioAnalyzer;
	private beatTimes: number[] = [];
	private startTime = 0;
	private gameStarted = false;
	private score = 0;
	private totalNotes = 0;
	private scoreText?: Phaser.GameObjects.Text;
	private timerText?: Phaser.GameObjects.Text;
	private gameTimer?: Phaser.Time.TimerEvent;
	private targetZone?: Phaser.GameObjects.Arc;
	private activeNotes: ColorNote[] = [];
	private colorKeys: { [key: string]: Phaser.Input.Keyboard.Key } = {};
	private songPath = "/public/music/track2.mp3";

	// Color scheme
	private readonly colors = [
		{ value: 0xff0000, name: "red", key: "A" },
		{ value: 0x00ff00, name: "green", key: "S" },
		{ value: 0x0000ff, name: "blue", key: "D" },
		{ value: 0xffff00, name: "yellow", key: "F" },
	];

	private colorTargets: Phaser.GameObjects.Rectangle[] = [];
	private currentColor: number = 0;
	private colorIndicator?: Phaser.GameObjects.Rectangle;

	constructor() {
		super({ key: "ColorMatchScene" });
	}

	preload() {
		this.load.audio("music", this.songPath);
	}

	async create() {
		super.create();
		const { width, height } = this.cameras.main;

		// Set black background for better color contrast
		this.cameras.main.setBackgroundColor("#000000");

		// Create target zone
		this.targetZone = this.add.circle(
			width / 2,
			height - 100,
			50,
			0xffffff,
			0.3,
		);

		// Add score text
		this.scoreText = this.add.text(10, 10, "Score: 0", {
			fontSize: "24px",
			fontFamily: "Arial Black",
			color: "#FFFFFF",
		});

		// Add timer text
		this.timerText = this.add.text(width / 2, 50, "Analyzing music...", {
			fontSize: "32px",
			fontFamily: "Arial Black",
			color: "#FFFFFF",
		});
		this.timerText.setOrigin(0.5);

		// Setup keyboard input
		this.colors.forEach((color) => {
			this.colorKeys[color.name] = this.input.keyboard!.addKey(color.key);

			// Add key indicator text
			const keyText = this.add.text(
				width / 2 + (Object.keys(this.colorKeys).length - 1) * 100 - 150,
				height - 50,
				color.key,
				{
					fontSize: "24px",
					fontFamily: "Arial Black",
					color: "#" + color.value.toString(16).padStart(6, "0"),
				},
			);
			keyText.setOrigin(0.5);
		});

		// Initialize audio analyzer
		this.audioAnalyzer = new AudioAnalyzer(this);

		try {
			console.log("Analyzing audio...");
			const beatInfo = await this.audioAnalyzer.analyzeSong(this.songPath);
			this.beatTimes = beatInfo.beatTimes;

			// Setup space to start the game
			this.input.keyboard?.on("keydown-SPACE", () => {
				if (!this.gameStarted) {
					this.startGame();
				}
			});

			this.timerText.setText("Press SPACE to start!");

			// Add instructions
			const instructions = this.add.text(
				width / 2,
				height - 150,
				"Press A, S, D, or F when the circles reach the target!",
				{
					fontSize: "24px",
					fontFamily: "Arial Black",
					color: "#FFFFFF",
				},
			);
			instructions.setOrigin(0.5);

			// Create color indicator
			this.colorIndicator = this.add.rectangle(
				width - 100,
				50,
				40,
				40,
				this.colors[0].value,
			);

			// Setup color cycling
			this.time.addEvent({
				delay: 2000,
				callback: this.cycleColor,
				callbackScope: this,
				loop: true,
			});
		} catch (error) {
			console.error("Error analyzing audio:", error);
			this.timerText.setText("Error loading music");
		}
	}

	private startGame() {
		this.gameStarted = true;
		this.startTime = this.time.now;
		this.score = 0;

		// Start playing the music
		this.music = this.sound.add("music");
		this.music.play();

		// Start the game timer (20 seconds)
		this.gameTimer = this.time.addEvent({
			delay: 20000,
			callback: this.endGame,
			callbackScope: this,
		});

		// Start updating the score display
		this.scoreText?.setText("Score: 0");
	}

	update() {
		if (!this.gameStarted) return;

		// Update timer text
		if (this.gameTimer && this.timerText) {
			const remaining = Math.ceil(20000 - this.gameTimer.getElapsed());
			this.timerText.setText(Math.ceil(remaining / 1000).toString());
		}

		const currentTime = this.time.now - this.startTime;

		// Create new notes based on beat times
		this.beatTimes.forEach((beatTime) => {
			if (
				Math.abs(currentTime - beatTime) < 16 && // One frame at 60fps (16ms)
				!this.activeNotes.some(
					(note) => Math.abs(note.startTime - beatTime) < 100,
				)
			) {
				// 100ms window
				this.createNote(beatTime);
			}
		});

		// Update existing notes
		this.updateNotes(currentTime);

		// Check for key presses
		this.checkKeyPresses();
	}

	private createNote(beatTime: number) {
		const { width, height } = this.cameras.main;
		const randomColor =
			this.colors[Math.floor(Math.random() * this.colors.length)];

		const circle = this.add.circle(width / 2, 100, 30, randomColor.value);

		this.activeNotes.push({
			circle,
			color: randomColor.value,
			colorName: randomColor.name,
			startTime: beatTime,
			hit: false,
		});
	}

	private updateNotes(currentTime: number) {
		const { height } = this.cameras.main;
		const targetY = height - 100; // Target zone Y position

		this.activeNotes = this.activeNotes.filter((note) => {
			if (note.hit) {
				note.circle.destroy();
				return false;
			}

			// Calculate progress (0 to 1)
			const noteTime = 1000; // Time for note to reach target (in milliseconds)
			const progress = (currentTime - note.startTime) / noteTime;

			if (progress >= 1) {
				// Note missed
				note.circle.destroy();
				return false;
			}

			// Update note position
			note.circle.y = 100 + (targetY - 100) * progress;

			// Scale and fade based on distance from target
			const distanceFromTarget = Math.abs(note.circle.y - targetY);
			const maxDistance = targetY - 100;
			const scale = 1 + 0.5 * (1 - distanceFromTarget / maxDistance);
			note.circle.setScale(scale);

			return true;
		});
	}

	private checkKeyPresses() {
		if (!this.targetZone) return;

		this.colors.forEach((color) => {
			const key = this.colorKeys[color.name];
			if (Phaser.Input.Keyboard.JustDown(key)) {
				const hitNote = this.findClosestNote(color.name);
				if (hitNote) {
					this.handleNoteHit(hitNote);
				}
			}
		});
	}

	private findClosestNote(colorName: string): ColorNote | null {
		if (!this.targetZone) return null;

		const targetY = this.targetZone.y;
		let closestNote: ColorNote | null = null;
		let closestDistance = Number.MAX_VALUE;

		this.activeNotes.forEach((note) => {
			if (note.colorName === colorName && !note.hit) {
				const distance = Math.abs(note.circle.y - targetY);
				if (distance < closestDistance) {
					closestDistance = distance;
					closestNote = note;
				}
			}
		});

		// Only return the note if it's within a reasonable distance (100 pixels ≈ 100ms timing window)
		return closestDistance < 100 ? closestNote : null;
	}

	private handleNoteHit(note: ColorNote) {
		if (!this.targetZone) return;

		const distance = Math.abs(note.circle.y - this.targetZone.y);
		const maxDistance = 100;

		// Calculate score based on timing accuracy (0-100)
		const hitScore = Math.max(
			0,
			Math.floor(100 * (1 - distance / maxDistance)),
		);

		// Update the running average score
		this.totalNotes++;
		this.score = Math.round(
			(this.score * (this.totalNotes - 1) + hitScore) / this.totalNotes,
		);
		this.scoreText?.setText(`Score: ${this.score}`);

		// Visual feedback
		note.hit = true;
		this.createHitEffect(note.circle.x, note.circle.y, note.color);
	}

	private createHitEffect(x: number, y: number, color: number) {
		// Create burst effect using circles
		for (let i = 0; i < 8; i++) {
			const angle = (i / 8) * Math.PI * 2;
			const burst = this.add.circle(x, y, 5, color);

			this.tweens.add({
				targets: burst,
				x: x + Math.cos(angle) * 50,
				y: y + Math.sin(angle) * 50,
				alpha: 0,
				scale: 0.5,
				duration: 300, // Already in milliseconds
				ease: "Power2",
				onComplete: () => {
					burst.destroy();
				},
			});
		}
	}

	private cycleColor() {
		this.currentColor = (this.currentColor + 1) % this.colors.length;
		if (this.colorIndicator) {
			this.colorIndicator.setFillStyle(this.colors[this.currentColor].value);
		}
	}

	private createColorTarget() {
		const { width, height } = this.cameras.main;
		const colorIndex = Math.floor(Math.random() * this.colors.length);
		const target = this.add.rectangle(
			width / 2,
			height - 100,
			60,
			60,
			this.colors[colorIndex].value,
		);
		this.colorTargets.push(target);

		this.tweens.add({
			targets: target,
			y: 100,
			duration: 2000,
			ease: "Linear",
			onComplete: () => {
				const index = this.colorTargets.indexOf(target);
				if (index !== -1) {
					this.colorTargets.splice(index, 1);
				}
				target.destroy();
			},
		});
	}

	private checkColorTargets() {
		for (let i = this.colorTargets.length - 1; i >= 0; i--) {
			const target = this.colorTargets[i];
			if (target.y > 300 && target.y < 500) {
				if (target.fillColor === this.colors[this.currentColor].value) {
					this.score += 100;
					if (this.scoreText) {
						this.scoreText.setText(`Score: ${this.score}`);
					}
					target.destroy();
					this.colorTargets.splice(i, 1);
					break;
				}
			}
		}
	}

	private endGame() {
		// Stop the music
		this.music?.stop();
		this.gameStarted = false;

		const { width, height } = this.cameras.main;

		// Show final score
		const finalScoreText = this.add.text(
			width / 2,
			height / 2,
			`Final Score: ${this.score}`,
			{
				fontSize: "64px",
				fontFamily: "Arial Black",
				color: "#FFFFFF",
			},
		);
		finalScoreText.setOrigin(0.5);

		// Add return to menu button
		const returnButton = this.add.text(
			width / 2,
			height / 2 + 100,
			"Return to Menu",
			{
				fontSize: "32px",
				fontFamily: "Arial Black",
				color: "#FFFFFF",
			},
		);
		returnButton.setOrigin(0.5);
		returnButton.setInteractive();
		returnButton.on("pointerdown", () => {
			this.scene.start("SelectionScene");
		});

		// Clean up
		this.activeNotes.forEach((note) => note.circle.destroy());
		this.activeNotes = [];
		this.timerText?.setVisible(false);
		this.targetZone?.setVisible(false);
		this.colorTargets.forEach((target) => target.destroy());
		this.colorTargets = [];
		this.score = 0;
	}
}
