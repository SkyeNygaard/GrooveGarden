import Phaser from "phaser";
import { AudioAnalyzer } from "../utils/audioAnalysis";
import { BaseScene } from "./BaseScene";

interface SyncNote {
	circle: Phaser.GameObjects.Arc;
	color: number;
	key: string;
	startTime: number;
	hit: boolean;
}

export class SoundSyncScene extends BaseScene {
	private music?: Phaser.Sound.BaseSound;
	private audioAnalyzer?: AudioAnalyzer;
	private beatTimes: number[] = [];
	private startTime = 0;
	private gameStarted = false;
	private activeNotes: SyncNote[] = [];
	private centerCircle?: Phaser.GameObjects.Arc;
	private outerRing?: Phaser.GameObjects.Arc;
	private statusText?: Phaser.GameObjects.Text;
	private scoreText?: Phaser.GameObjects.Text;
	private score = 0;
	private songPath = "/public/music/Suno1.mp3";
	private gameTimer?: Phaser.Time.TimerEvent;

	// Color scheme and keys
	private readonly notes = [
		{ color: 0xff0000, key: "A" },
		{ color: 0x00ff00, key: "S" },
		{ color: 0x0000ff, key: "D" },
		{ color: 0xffff00, key: "F" },
	];

	private visualizers: Phaser.GameObjects.Rectangle[] = [];
	private currentBeatIndex: number = 0;

	constructor() {
		super({ key: "SoundSyncScene" });
	}

	preload() {
		this.load.audio("suno1", this.songPath);
	}

	async create() {
		super.create();
		const { width, height } = this.cameras.main;

		// Set dark background for better effect visibility
		this.cameras.main.setBackgroundColor("#000000");

		// Create center circle (source of notes)
		this.centerCircle = this.add.circle(
			width / 2,
			height / 2,
			30,
			0x4444ff,
			0.8,
		);

		// Create outer ring (target zone)
		this.outerRing = this.add
			.circle(width / 2, height / 2, 200, 0x4444ff, 0.4)
			.setStrokeStyle(4, 0x6666ff);

		// Add score text
		this.scoreText = this.add.text(10, 10, "Score: 0", {
			fontSize: "24px",
			fontFamily: "Arial",
			color: "#FFFFFF",
		});

		// Add status text
		this.statusText = this.add.text(
			width / 2,
			height - 100,
			"Analyzing music...",
			{
				fontSize: "24px",
				fontFamily: "Arial",
				color: "#FFFFFF",
			},
		);
		this.statusText.setOrigin(0.5);

		// Setup key indicators around the outer ring
		this.notes.forEach((note, index) => {
			const angle = (index * Math.PI) / 2 - Math.PI / 4; // Distribute evenly in a circle
			const x = width / 2 + Math.cos(angle) * 200;
			const y = height / 2 + Math.sin(angle) * 200;

			// Add key indicator
			const keyText = this.add
				.text(x, y, note.key, {
					fontSize: "24px",
					fontFamily: "Arial",
					color: "#" + note.color.toString(16).padStart(6, "0"),
				})
				.setOrigin(0.5);

			// Add key listeners
			const key = this.input.keyboard!.addKey(note.key);
			key.on("down", () => this.handleKeyPress(note.color));
		});

		// Initialize audio analyzer
		this.audioAnalyzer = new AudioAnalyzer(this);

		try {
			console.log("Analyzing Suno1 audio...");
			const beatInfo = await this.audioAnalyzer.analyzeSong(this.songPath);
			this.beatTimes = beatInfo.beatTimes;

			// Setup space to start
			this.input.keyboard?.on("keydown-SPACE", () => {
				if (!this.gameStarted) {
					this.startGame();
				}
			});

			this.statusText.setText("Press SPACE to start!");

			// Add instructions
			const instructions = this.add
				.text(
					width / 2,
					height - 150,
					"Press A, S, D, or F when the circles reach the outer ring!",
					{
						fontSize: "24px",
						fontFamily: "Arial",
						color: "#FFFFFF",
					},
				)
				.setOrigin(0.5);

			// Create visualizers
			const visualizerCount = 8;
			const spacing = width / (visualizerCount + 1);
			for (let i = 0; i < visualizerCount; i++) {
				const visualizer = this.add.rectangle(
					spacing * (i + 1),
					height - 100,
					30,
					100,
					0x00ff00,
				);
				this.visualizers.push(visualizer);
			}
		} catch (error) {
			console.error("Error analyzing audio:", error);
			this.statusText.setText("Error loading music");
		}
	}

	private startGame() {
		this.gameStarted = true;
		this.startTime = this.time.now;
		this.score = 0;

		// Start playing the music
		this.music = this.sound.add("suno1");
		this.music.play();

		// Hide status text
		this.statusText?.setVisible(false);

		// Start game timer (30 seconds)
		this.gameTimer = this.time.addEvent({
			delay: 30000,
			callback: this.endGame,
			callbackScope: this,
		});
	}

	update() {
		if (!this.gameStarted) return;

		const currentTime = this.time.now - this.startTime;

		// Update timer if exists
		if (this.gameTimer && this.statusText?.visible) {
			const remaining = Math.ceil(30000 - this.gameTimer.getElapsed());
			this.statusText.setText(Math.ceil(remaining / 1000).toString());
		}

		// Create new notes based on beat times
		this.beatTimes.forEach((beatTime) => {
			if (
				Math.abs(currentTime - beatTime) < 16 && // One frame at 60fps
				!this.activeNotes.some(
					(note) => Math.abs(note.startTime - beatTime) < 100,
				)
			) {
				this.createNote(beatTime);
			}
		});

		// Update existing notes
		this.updateNotes(currentTime);
	}

	private createNote(beatTime: number) {
		const { width, height } = this.cameras.main;

		// Choose random note type
		const noteType = this.notes[Math.floor(Math.random() * this.notes.length)];

		// Create note at center
		const circle = this.add.circle(
			width / 2,
			height / 2,
			15,
			noteType.color,
			1,
		);

		this.activeNotes.push({
			circle,
			color: noteType.color,
			key: noteType.key,
			startTime: beatTime,
			hit: false,
		});
	}

	private updateNotes(currentTime: number) {
		const { width, height } = this.cameras.main;

		this.activeNotes = this.activeNotes.filter((note) => {
			if (note.hit) {
				note.circle.destroy();
				return false;
			}

			// Calculate progress (0 to 1)
			const noteTime = 1000; // Time for note to reach target (in milliseconds)
			const progress = (currentTime - note.startTime) / noteTime;

			if (progress >= 1.2) {
				// Give a little extra time before removing
				note.circle.destroy();
				return false;
			}

			// Update note position (move from center to edge)
			const radius = progress * 200; // 200 is the outer ring radius
			const angle =
				(this.notes.findIndex((n) => n.color === note.color) * Math.PI) / 2 -
				Math.PI / 4;
			note.circle.x = width / 2 + Math.cos(angle) * radius;
			note.circle.y = height / 2 + Math.sin(angle) * radius;

			return true;
		});
	}

	private handleKeyPress(color: number) {
		if (!this.gameStarted) return;

		// Find the closest note of matching color
		const currentTime = this.time.now - this.startTime;
		let closestNote: SyncNote | null = null;
		let closestDistance = Number.MAX_VALUE;

		this.activeNotes.forEach((note) => {
			if (!note.hit && note.color === color) {
				const distance = Math.abs(
					Math.sqrt(
						Math.pow(note.circle.x - this.outerRing!.x, 2) +
							Math.pow(note.circle.y - this.outerRing!.y, 2),
					) - this.outerRing!.radius,
				);

				if (distance < closestDistance) {
					closestDistance = distance;
					closestNote = note;
				}
			}
		});

		// If we found a close enough note, count it as a hit
		if (closestNote && closestDistance < 50) {
			closestNote.hit = true;
			this.score += Math.max(100 - Math.floor(closestDistance), 10);
			this.scoreText?.setText(`Score: ${this.score}`);
			this.createHitEffect(
				closestNote.circle.x,
				closestNote.circle.y,
				closestNote.color,
			);
		}
	}

	private createHitEffect(x: number, y: number, color: number) {
		// Create burst effect
		for (let i = 0; i < 8; i++) {
			const angle = (i * Math.PI * 2) / 8;
			const burst = this.add.circle(x, y, 5, color, 1);

			this.tweens.add({
				targets: burst,
				x: x + Math.cos(angle) * 50,
				y: y + Math.sin(angle) * 50,
				alpha: 0,
				scale: 0.5,
				duration: 300,
				ease: "Power2",
				onComplete: () => {
					burst.destroy();
				},
			});
		}
	}

	private endGame = () => {
		if (this.music) {
			this.music.stop();
		}

		const { width, height } = this.cameras.main;

		// Show final score
		this.add
			.text(width / 2, height / 2, `Final Score: ${this.score}`, {
				fontSize: "48px",
				fontFamily: "Arial",
				color: "#FFFFFF",
			})
			.setOrigin(0.5);

		// Add replay instruction
		this.add
			.text(width / 2, height / 2 + 60, "Press SPACE to play again", {
				fontSize: "24px",
				fontFamily: "Arial",
				color: "#FFFFFF",
			})
			.setOrigin(0.5);

		this.gameStarted = false;

		// Clear active notes
		this.activeNotes.forEach((note) => note.circle.destroy());
		this.activeNotes = [];
	};

	onBeat(beatNumber: number, time: number): void {
		// Highlight current visualizer
		const currentVisualizer = this.visualizers[this.currentBeatIndex];
		if (currentVisualizer) {
			currentVisualizer.setFillStyle(0xff0000);
			this.tweens.add({
				targets: currentVisualizer,
				scaleY: 2,
				duration: 100,
				yoyo: true,
				onComplete: () => {
					currentVisualizer.setFillStyle(0x00ff00);
				},
			});
		}

		this.currentBeatIndex = (this.currentBeatIndex + 1) % this.visualizers.length;
	}

	onInput(type: string, event: any): void {
		if (type === "keydown") {
			const key = event.key.toLowerCase();
			const index = "12345678".indexOf(key);
			if (index !== -1 && index === this.currentBeatIndex) {
				this.score += 100;
				if (this.scoreText) {
					this.scoreText.setText(`Score: ${this.score}`);
				}
				this.visualizers[index].setFillStyle(0x0000ff);
				this.time.delayedCall(100, () => {
					this.visualizers[index].setFillStyle(0x00ff00);
				});
			}
		}
	}

	shutdown() {
		this.visualizers.forEach(visualizer => visualizer.destroy());
		this.visualizers = [];
		this.score = 0;
	}
}
