import { Scene } from "phaser";
import type { BeatListener } from "../core/interfaces/BeatListener";
import type { InputListener } from "../core/input/InputManager";
import { InputManager } from "../core/input/InputManager";
import { SongManager } from "../core/managers/SongManager";

export class BeatBoxScene extends Scene implements BeatListener, InputListener {
	private songManager!: SongManager;
	private inputManager!: InputManager;
	private score: number = 0;
	private scoreText?: Phaser.GameObjects.Text;

	constructor() {
		super({ key: "BeatBoxScene" });
	}

	create() {
		// Initialize managers
		this.songManager = new SongManager(this);
		this.inputManager = new InputManager(this);

		// Setup input handling
		this.inputManager.addListener("keydown", this);
		this.inputManager.addListener("pointerdown", this);

		// Setup UI
		this.scoreText = this.add.text(16, 16, "Score: 0", {
			fontSize: "32px",
			color: "#fff",
		});

		// Load and start song
		this.songManager.loadSong({
			key: "beatbox-song",
			bpm: 120,
			duration: 60,
		});

		// Register as beat listener
		this.songManager.getBeatManager().addListener(this);

		// Start the song
		this.songManager.play();
	}

	update() {
		this.songManager.update();
	}

	// BeatListener implementation
	onBeat(beatNumber: number, time: number): void {
		// Visual feedback for the beat
		this.cameras.main.flash(100, 255, 255, 255, 0.2);
	}

	onBeatEarly(beatNumber: number, timeDiff: number): void {
		// Visual feedback for early hit
		this.cameras.main.flash(100, 255, 0, 0, 0.2);
	}

	onBeatLate(beatNumber: number, timeDiff: number): void {
		// Visual feedback for late hit
		this.cameras.main.flash(100, 0, 0, 255, 0.2);
	}

	// InputListener implementation
	onInput(type: string, event: any): void {
		if (type === "keydown" || type === "pointerdown") {
			// Check if this input matches with a beat
			this.songManager.getBeatManager().checkBeatHit(Date.now());
		}
	}

	shutdown() {
		this.songManager.stop();
		this.inputManager.removeListener("keydown", this);
		this.inputManager.removeListener("pointerdown", this);
	}
}
