import Phaser from "phaser";

interface GameItem {
	name: string;
	color: number;
	thumbnail?: string;
	scene: string;
	description?: string;
}

export class SelectionScene extends Phaser.Scene {
	private cursor?: Phaser.GameObjects.Rectangle;
	private games: (Phaser.GameObjects.Rectangle | Phaser.GameObjects.Image)[] = [];
	private gameTexts: Phaser.GameObjects.Text[] = [];
	private selectedIndex = 0;
	private cursorTween?: Phaser.Tweens.Tween;
	private readonly ROWS = 2;
	private readonly COLS = 3;
	private readonly TOTAL_GAMES = 6;
	private descriptionText?: Phaser.GameObjects.Text;
	private gameItems: GameItem[] = [];

	constructor() {
		super({ key: "SelectionScene" });
		this.selectedIndex = 0;
	}

	preload() {
		this.load.image("russianBounce", "/public/images/RussianBounceThumbnail.png");
	}

	create() {
		const width = this.cameras.main.width;
		const height = this.cameras.main.height;

		// Set white background
		this.cameras.main.setBackgroundColor("#FFFFFF");

		this.gameItems = [
			{
				name: "Tap Beat",
				color: 0xff0000,
				scene: "TapBeatScene",
				description: "Test your rhythm! Tap to the beat of the music to score points.",
			},
			{
				name: "Color Match",
				color: 0x00ff00,
				scene: "ColorMatchScene",
				description: "Match the colors as they appear to the rhythm of the music.",
			},
			{
				name: "Sound Sync",
				color: 0x0000ff,
				scene: "SoundSyncScene",
				description: "Follow the beat pattern and sync with the music visualization.",
			},
			{
				name: "Beat Box",
				color: 0xffff00,
				scene: "BeatBoxScene",
				description: "Create your own beats and rhythms in this interactive beat maker.",
			},
			{
				name: "Russian Bounce",
				color: 0x4169e1,
				thumbnail: "russianBounce",
				scene: "RussianBounceScene",
				description: "Keep the ball bouncing in sync with the music!",
			},
			{
				name: "Coming Soon",
				color: 0x808080,
				scene: "",
				description: "More rhythm games coming soon!",
			},
		];

		// Calculate grid layout
		const padding = height * 0.1; // 10% padding
		const availableWidth = width - padding * 2;
		const availableHeight = height * 0.6; // Use only 60% of height for grid
		const itemWidth = availableWidth / this.COLS;
		const itemHeight = availableHeight / this.ROWS;
		const squareSize = Math.min(itemWidth, itemHeight) * 0.7; // 70% of available space

		// Create game squares in grid
		for (let row = 0; row < this.ROWS; row++) {
			for (let col = 0; col < this.COLS; col++) {
				const index = row * this.COLS + col;
				const game = this.gameItems[index];
				if (!game) continue;

				const x = padding + itemWidth * (col + 0.5);
				const y = padding + itemHeight * (row + 0.5);

				let gameObject;
				if (game.thumbnail && this.textures.exists(game.thumbnail)) {
					gameObject = this.add
						.image(x, y, game.thumbnail)
						.setDisplaySize(squareSize, squareSize);
				} else {
					gameObject = this.add.rectangle(x, y, squareSize, squareSize, game.color);
				}
				
				// Make game object interactive
				gameObject.setInteractive()
					.on('pointerover', () => this.onGameHover(index))
					.on('pointerdown', () => this.selectGame());

				this.games.push(gameObject);

				// Add game name below square
				const text = this.add.text(x, y + squareSize * 0.7, game.name, {
					fontSize: Math.floor(squareSize * 0.15) + "px",
					fontFamily: "Arial Black",
					color: "#000000",
				});
				text.setOrigin(0.5);
				this.gameTexts.push(text);

				// Add bounce animation for available games
				if (game.scene) {
					this.tweens.add({
						targets: gameObject,
						y: y - squareSize * 0.05,
						duration: 1000,
						yoyo: true,
						repeat: -1,
						ease: "Quad.easeInOut",
						delay: index * 100,
					});
				}
			}
		}

		// Create selection cursor
		this.cursor = this.add.rectangle(
			this.games[0].x,
			this.games[0].y,
			squareSize * 1.2,
			squareSize * 1.2,
			0x000000,
		);
		this.cursor.setStrokeStyle(4, 0x000000);
		this.cursor.setFillStyle(0x000000, 0);

		// Add cursor animation
		this.cursorTween = this.tweens.add({
			targets: this.cursor,
			scaleX: 1.1,
			scaleY: 1.1,
			duration: 500,
			yoyo: true,
			repeat: -1,
		});

		// Add keyboard controls
		this.input.keyboard?.on("keydown-LEFT", () => this.moveSelection(-1));
		this.input.keyboard?.on("keydown-RIGHT", () => this.moveSelection(1));
		this.input.keyboard?.on("keydown-UP", () => this.moveSelection(-this.COLS));
		this.input.keyboard?.on("keydown-DOWN", () => this.moveSelection(this.COLS));
		this.input.keyboard?.on("keydown-SPACE", () => this.selectGame());
		this.input.keyboard?.on("keydown-ENTER", () => this.selectGame());

		// Add title at the top
		const title = this.add.text(width / 2, padding / 2, "GROOVE GARDEN", {
			fontSize: Math.floor(height * 0.06) + "px",
			fontFamily: "Arial Black",
			color: "#000000",
		});
		title.setOrigin(0.5);

		// Add description text area
		this.descriptionText = this.add.text(
			width / 2,
			height - padding,
			this.gameItems[0].description || "",
			{
				fontSize: Math.floor(height * 0.03) + "px",
				fontFamily: "Arial",
				color: "#000000",
				align: "center",
				wordWrap: { width: width * 0.8 },
			}
		);
		this.descriptionText.setOrigin(0.5);

		// Add instruction text
		const instructions = this.add.text(
			width / 2,
			height - padding * 2,
			"← → ↑ ↓ to move    SPACE/ENTER to select",
			{
				fontSize: Math.floor(height * 0.03) + "px",
				fontFamily: "Arial Black",
				color: "#000000",
			}
		);
		instructions.setOrigin(0.5);

		// Initialize first game description
		this.updateDescription();
	}

	private moveSelection(direction: number) {
		const newIndex = (this.selectedIndex + direction + this.TOTAL_GAMES) % this.TOTAL_GAMES;
		if (this.games[newIndex]) {
			this.selectedIndex = newIndex;
			this.cursor?.setPosition(this.games[newIndex].x, this.games[newIndex].y);
			this.updateDescription();
			
			// Add highlight effect
			const selectedGame = this.games[newIndex];
			this.tweens.add({
				targets: selectedGame,
				scaleX: 1.1,
				scaleY: 1.1,
				duration: 200,
				yoyo: true,
			});
		}
	}

	private onGameHover(index: number) {
		if (index !== this.selectedIndex) {
			this.moveSelection(index - this.selectedIndex);
		}
	}

	private updateDescription() {
		if (this.descriptionText) {
			const game = this.gameItems[this.selectedIndex];
			this.descriptionText.setText(game.description || "");
		}
	}

	private selectGame() {
		const game = this.gameItems[this.selectedIndex];
		if (game && game.scene) {
			// Add selection animation
			const selectedGame = this.games[this.selectedIndex];
			this.tweens.add({
				targets: selectedGame,
				scaleX: 1.2,
				scaleY: 1.2,
				alpha: 0.8,
				duration: 200,
				onComplete: () => {
					this.scene.start(game.scene);
				}
			});
		}
	}
}
