export interface BeatListener {
    onBeat(beatNumber: number, time: number): void;
    onBeatMissed?(beatNumber: number): void;
    onBeatEarly?(beatNumber: number, timeDiff: number): void;
    onBeatLate?(beatNumber: number, timeDiff: number): void;
}
