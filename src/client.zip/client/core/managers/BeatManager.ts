import { BeatListener } from '../interfaces/BeatListener';

export class BeatManager {
    private listeners: BeatListener[] = [];
    private currentBeat: number = 0;
    private bpm: number = 120;
    private isPlaying: boolean = false;
    private beatInterval: number = 0;
    private lastBeatTime: number = 0;
    private toleranceWindow: number = 100; // ms tolerance for early/late beats

    constructor(bpm: number = 120) {
        this.bpm = bpm;
        this.beatInterval = (60 / bpm) * 1000; // Convert to milliseconds
    }

    addListener(listener: BeatListener): void {
        this.listeners.push(listener);
    }

    removeListener(listener: BeatListener): void {
        const index = this.listeners.indexOf(listener);
        if (index > -1) {
            this.listeners.splice(index, 1);
        }
    }

    start(): void {
        this.isPlaying = true;
        this.currentBeat = 0;
        this.lastBeatTime = Date.now();
    }

    stop(): void {
        this.isPlaying = false;
    }

    update(): void {
        if (!this.isPlaying) return;

        const currentTime = Date.now();
        const timeSinceLastBeat = currentTime - this.lastBeatTime;

        if (timeSinceLastBeat >= this.beatInterval) {
            this.lastBeatTime = currentTime;
            this.currentBeat++;
            this.notifyListeners(this.currentBeat, currentTime);
        }
    }

    checkBeatHit(time: number): void {
        if (!this.isPlaying) return;

        const timeSinceLastBeat = time - this.lastBeatTime;
        const timeUntilNextBeat = this.beatInterval - timeSinceLastBeat;

        if (Math.abs(timeUntilNextBeat) <= this.toleranceWindow) {
            // Perfect hit
            this.notifyListeners(this.currentBeat + 1, time);
        } else if (timeUntilNextBeat > this.toleranceWindow) {
            // Early hit
            this.listeners.forEach(listener => {
                if (listener.onBeatEarly) {
                    listener.onBeatEarly(this.currentBeat + 1, timeUntilNextBeat);
                }
            });
        } else {
            // Late hit
            this.listeners.forEach(listener => {
                if (listener.onBeatLate) {
                    listener.onBeatLate(this.currentBeat, Math.abs(timeUntilNextBeat));
                }
            });
        }
    }

    setBPM(bpm: number): void {
        this.bpm = bpm;
        this.beatInterval = (60 / bpm) * 1000;
    }

    private notifyListeners(beatNumber: number, time: number): void {
        this.listeners.forEach(listener => {
            listener.onBeat(beatNumber, time);
        });
    }
}
