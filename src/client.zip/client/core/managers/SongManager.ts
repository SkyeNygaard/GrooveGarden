import { BeatManager } from './BeatManager';

export interface Song {
    key: string;
    bpm: number;
    duration: number;
}

export class SongManager {
    private currentSong?: Song;
    private beatManager: BeatManager;
    private scene: Phaser.Scene;
    private isLoaded: boolean = false;

    constructor(scene: Phaser.Scene) {
        this.scene = scene;
        this.beatManager = new BeatManager();
    }

    async loadSong(song: Song): Promise<void> {
        this.currentSong = song;
        this.beatManager.setBPM(song.bpm);
        this.isLoaded = true;
    }

    play(): void {
        if (!this.isLoaded || !this.currentSong) return;
        
        // Start the audio
        const music = this.scene.sound.add(this.currentSong.key);
        music.play();
        
        // Start the beat manager
        this.beatManager.start();
    }

    stop(): void {
        this.scene.sound.stopAll();
        this.beatManager.stop();
    }

    getBeatManager(): BeatManager {
        return this.beatManager;
    }

    update(): void {
        if (this.isLoaded) {
            this.beatManager.update();
        }
    }
}
