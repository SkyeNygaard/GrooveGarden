export interface InputListener {
    onInput(type: string, event: any): void;
}

export class InputManager {
    private scene: Phaser.Scene;
    private listeners: Map<string, InputListener[]> = new Map();

    constructor(scene: Phaser.Scene) {
        this.scene = scene;
        this.setupInputs();
    }

    private setupInputs(): void {
        // Setup keyboard inputs
        this.scene.input.keyboard?.on('keydown', (event: KeyboardEvent) => {
            this.notifyListeners('keydown', event);
        });

        // Setup mouse/touch inputs
        this.scene.input.on('pointerdown', (pointer: Phaser.Input.Pointer) => {
            this.notifyListeners('pointerdown', pointer);
        });

        this.scene.input.on('pointerup', (pointer: Phaser.Input.Pointer) => {
            this.notifyListeners('pointerup', pointer);
        });
    }

    addListener(type: string, listener: InputListener): void {
        if (!this.listeners.has(type)) {
            this.listeners.set(type, []);
        }
        this.listeners.get(type)?.push(listener);
    }

    removeListener(type: string, listener: InputListener): void {
        const typeListeners = this.listeners.get(type);
        if (typeListeners) {
            const index = typeListeners.indexOf(listener);
            if (index > -1) {
                typeListeners.splice(index, 1);
            }
        }
    }

    private notifyListeners(type: string, event: any): void {
        const typeListeners = this.listeners.get(type);
        if (typeListeners) {
            typeListeners.forEach(listener => {
                listener.onInput(type, event);
            });
        }
    }
}
