import { Scene } from 'phaser';
import { guess } from 'web-audio-beat-detector';

interface BeatInfo {
    bpm: number;
    beatTimes: number[];
    offset?: number;
    tempo?: number;
}

export class AudioAnalyzer {
    private audioContext: AudioContext;
    private scene: Scene;

    constructor(scene: Scene) {
        this.scene = scene;
        this.audioContext = new AudioContext();
    }

    async analyzeSong(audioPath: string): Promise<BeatInfo> {
        try {
            // Use the direct file path instead of Phaser's cache
            // Create a temporary audio element
            const audio = new Audio(audioPath);
            console.log('Loading audio from:', audioPath);
            
            await new Promise((resolve, reject) => {
                audio.addEventListener('loadeddata', resolve);
                audio.addEventListener('error', (e) => {
                    console.error('Audio loading error:', e);
                    reject(e);
                });
                audio.load();
            });

            // Create an AudioBuffer from the audio element
            const response = await fetch(audioPath);
            const arrayBuffer = await response.arrayBuffer();
            const audioBuffer = await this.audioContext.decodeAudioData(arrayBuffer);

            // Use web-audio-beat-detector's guess function
            const { bpm, offset, tempo } = await guess(audioBuffer);
            console.log(bpm, offset, tempo);
            
            // Calculate beat times based on the BPM and offset
            const beatTimes = this.generateBeatTimes(bpm, offset, audioBuffer.duration);
            console.log(beatTimes);

            return {
                bpm,
                beatTimes,
                offset,
                tempo
            };
        } catch (error) {
            console.error('Error analyzing audio:', error);
            // Return default values if analysis fails
            return {
                bpm: 120,
                beatTimes: this.generateDefaultBeatTimes(120)
            };
        }
    }

    private generateBeatTimes(bpm: number, offset: number, duration: number): number[] {
        const beatInterval = 60 / bpm; // Convert BPM to seconds per beat
        const beatTimes: number[] = [];
        
        // Start from the first beat (offset) and add beats until we reach the end of the audio
        let currentBeat = offset;
        while (currentBeat < duration) {
            beatTimes.push(currentBeat * 1000); // Convert to milliseconds
            currentBeat += beatInterval;
        }
        
        return beatTimes;
    }

    private generateDefaultBeatTimes(bpm: number): number[] {
        const beatInterval = 60 / bpm;
        const beatTimes: number[] = [];
        for (let time = 0; time < 60; time += beatInterval) { // Generate 60 seconds worth of beats
            beatTimes.push(time * 1000); // Convert to milliseconds
        }
        return beatTimes;
    }

    // Clean up resources
    destroy() {
        this.audioContext.close();
    }
}
